package ogs.mag.nexozone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

data class Post(
    val id: String,
    val authorEmail: String,
    val authorUid: String,
    val username: String,
    val description: String,
    val imageUrl: String,
    var likes: Int,
    var isLiked: Boolean = false,
    var likedBy: MutableList<String> = mutableListOf()
)

class PostAdapter(private val posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {
    
    private var isUpdatingLike = false // Control de ráfagas de clics

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val username: TextView = view.findViewById(R.id.textUsername)
        val description: TextView = view.findViewById(R.id.textDescription)
        val imagePost: android.widget.ImageView = view.findViewById(R.id.imagePost)
        val likesCount: TextView = view.findViewById(R.id.textLikesCount)
        val buttonLike: TextView = view.findViewById(R.id.buttonLike)
        val buttonComment: TextView = view.findViewById(R.id.buttonComment)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        // CORRECCIÓN: Se usa R.layout.item_post en lugar de R.id.item_post
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        val context = holder.itemView.context

        holder.username.text = post.username
        holder.description.text = post.description

        if (post.imageUrl.isNotEmpty()) {
            val imageUri = android.net.Uri.parse(post.imageUrl)
            try {
                // VERIFICACIÓN Y CARGA SEGURA:
                if (imageUri.scheme == "content") {
                    // Decodificamos a Bitmap para evitar colapso en onMeasure
                    val inputStream = context.contentResolver.openInputStream(imageUri)
                    val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                    inputStream?.close()
                    if (bitmap != null) {
                        holder.imagePost.visibility = View.VISIBLE
                        holder.imagePost.setImageBitmap(bitmap)
                    } else {
                        holder.imagePost.visibility = View.GONE
                    }
                } else {
                    holder.imagePost.visibility = View.VISIBLE
                    holder.imagePost.setImageURI(imageUri)
                }
            } catch (e: Exception) {
                // Atrapa SecurityException y cualquier otro error de lectura
                android.util.Log.w("PostAdapter", "Imagen no disponible: ${e.message}")
                holder.imagePost.visibility = View.GONE
            }
        } else {
            holder.imagePost.visibility = View.GONE
        }

        // Uso de placeholders desde strings.xml
        holder.likesCount.text = context.getString(R.string.likes_placeholder, post.likes)
        holder.buttonLike.text = if (post.isLiked)
            context.getString(R.string.liked_icon)
        else context.getString(R.string.like_icon)

        holder.buttonLike.setOnClickListener {
            try {
                val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
                val user = auth.currentUser ?: return@setOnClickListener
                val userUid = user.uid
                val userEmail = user.email ?: ""
                
                // 1. CAMBIO VISUAL INMEDIATO (User Experience)
                post.isLiked = !post.isLiked
                if (post.isLiked) {
                    post.likes++
                    if (!post.likedBy.contains(userEmail)) post.likedBy.add(userEmail)
                    holder.buttonLike.text = context.getString(R.string.liked_icon)
                } else {
                    post.likes--
                    post.likedBy.remove(userEmail)
                    holder.buttonLike.text = context.getString(R.string.like_icon)
                }
                holder.likesCount.text = context.getString(R.string.likes_placeholder, post.likes)

                // 2. ACTUALIZACIÓN ASÍNCRONA (Firebase con BLINDAJE)
                if (!post.id.isNullOrBlank() && !post.id.startsWith("mock")) {
                    val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    val postRef = db.collection("posts").document(post.id)
                    
                    val updateTask = if (post.isLiked) {
                        postRef.update(
                            "likes", post.likes,
                            "likedBy", com.google.firebase.firestore.FieldValue.arrayUnion(userEmail)
                        )
                    } else {
                        postRef.update(
                            "likes", post.likes,
                            "likedBy", com.google.firebase.firestore.FieldValue.arrayRemove(userEmail)
                        )
                    }

                    updateTask.addOnSuccessListener {
                        if (post.isLiked) {
                            // Enviar NOTIFICACIÓN SILENCIOSA si el post tiene autor válido (UID)
                            if (!post.authorUid.isNullOrBlank() && post.authorUid != userUid) {
                                sendNotification(db, userUid, post.authorUid, post.description)
                            }
                        }
                    }.addOnFailureListener { e ->
                        android.util.Log.e("LikeDB", "Error al guardar: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                // ESCUDO: Captura cualquier error para evitar el cierre de la app
                android.util.Log.e("PostAdapter", "Cierre evitado en Like: ${e.message}", e)
                Toast.makeText(context, "Acción no disponible temporalmente", Toast.LENGTH_SHORT).show()
            }
        }
        // 3. Listeners de Navegación
        holder.username.setOnClickListener {
            val intent = android.content.Intent(context, OtherUserProfileActivity::class.java)
            intent.putExtra("USERNAME", post.username.removePrefix("@"))
            context.startActivity(intent)
        }

        holder.buttonComment.setOnClickListener {
            val intent = android.content.Intent(context, CommentsActivity::class.java)
            intent.putExtra("POST_ID", post.id)
            intent.putExtra("AUTHOR_EMAIL", post.authorEmail)
            intent.putExtra("AUTHOR_UID", post.authorUid)
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = posts.size

    private fun sendNotification(db: com.google.firebase.firestore.FirebaseFirestore, fromUid: String, toUid: String, postDesc: String?) {
        // SEGURIDAD: Nunca intentar contactar con un UID vacío o inexistente
        if (fromUid.isBlank() || toUid.isBlank()) return

        db.collection("users").document(fromUid).get().addOnSuccessListener { doc ->
            if (doc.exists()) {
                try {
                    val myUn = doc.getString("username") ?: "Usuario"
                    val desc = postDesc ?: "un post"
                    val postPreview = if (desc.length > 20) desc.take(20) + "..." else desc
                    
                    val notifData = hashMapOf(
                        "text" to "@$myUn le dio Like a tu post: '$postPreview'",
                        "type" to "LIKE",
                        "isRead" to false,
                        "timestamp" to com.google.firebase.Timestamp.now()
                    )
                    
                    // Usamos add() para crear un ID único en la sub-colección del destinatario (UID)
                    db.collection("users").document(toUid)
                        .collection("notifications").add(notifData)
                } catch (e: Exception) {
                    android.util.Log.e("Notif", "Error silencioso en notificación: ${e.message}")
                }
            }
        }
    }

}