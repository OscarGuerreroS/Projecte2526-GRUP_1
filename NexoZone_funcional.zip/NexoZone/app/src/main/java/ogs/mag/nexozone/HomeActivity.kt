package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import android.widget.ImageView

class HomeActivity : AppCompatActivity() {

    private lateinit var postAdapter: PostAdapter
    private val postsList = mutableListOf<Post>()
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private var postListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var lastLoadedUserEmail: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<ImageView>(R.id.btnSearch)?.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }

        findViewById<ImageView>(R.id.btnNotifications)?.setOnClickListener {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }

        findViewById<ImageView>(R.id.btnSettings)?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // 1. Configurar el RecyclerView
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewFeed)
        postAdapter = PostAdapter(postsList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = postAdapter

        // 2. Configurar el Menú Inferior
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_home

        // Listener de Seguridad: Solo cargar datos cuando Firebase Auth esté listo
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null && user.email != lastLoadedUserEmail) {
                lastLoadedUserEmail = user.email
                loadPosts()
                listenForUnreadMessages(bottomNav)
                listenForNotifications()
                checkUserDocument()
            }
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddPostActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }

        // Se cargará mediante el AuthStateListener
    }

    private fun checkUserDocument() {
        val user = auth.currentUser ?: return
        val uid = user.uid
        val email = user.email ?: "no-email"
        
        db.collection("users").document(uid).get().addOnSuccessListener { doc ->
            val userData = hashMapOf(
                "email" to email,
                "uid" to uid
            )
            // Usamos merge para NO borrar lo que ya existe (bio, fotos), pero asegurar email y uid
            db.collection("users").document(uid).set(userData, com.google.firebase.firestore.SetOptions.merge())
                .addOnSuccessListener {
                    android.util.Log.d("Home", "Perfil UID actualizado con Email: $email")
                }
        }
    }

    private fun listenForNotifications() {
        val uid = auth.currentUser?.uid ?: return
        val tvBadge = findViewById<android.widget.TextView>(R.id.tvNotificationBadge)

        db.collection("users").document(uid).collection("notifications")
            .whereEqualTo("isRead", false)
            .addSnapshotListener { snapshots, e ->
                if (e != null || snapshots == null) return@addSnapshotListener
                
                val count = snapshots.size()
                if (count > 0) {
                    tvBadge.visibility = android.view.View.VISIBLE
                    tvBadge.text = if (count > 9) "9+" else count.toString()
                } else {
                    tvBadge.visibility = android.view.View.GONE
                }
            }
    }

    private fun listenForUnreadMessages(bottomNav: BottomNavigationView) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("users").document(uid).collection("recentChats")
            .addSnapshotListener { snapshots, e ->
                if (e != null || snapshots == null) return@addSnapshotListener
                
                var totalUnread = 0
                for (doc in snapshots) {
                    val unread = doc.getLong("unreadCount")?.toInt() ?: 0
                    totalUnread += unread
                }
                
                if (totalUnread > 0) {
                    val badge = bottomNav.getOrCreateBadge(R.id.nav_chat)
                    badge.isVisible = true
                    badge.number = totalUnread
                } else {
                    bottomNav.removeBadge(R.id.nav_chat)
                }
            }
    }

    private fun loadPosts() {
        if (auth.currentUser == null) return
        
        // LIMPIEZA: Remover listener antiguo antes de crear uno nuevo
        postListener?.remove()

        postListener = db.collection("posts")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) return@addSnapshotListener

                if (snapshots != null) {
                    // Si no hay publicaciones, agregar datos de prueba
                    if (snapshots.isEmpty) {
                        createPokemonMockPosts()
                        // Firestore emitirá otro snapshot al insertar, así que salimos de este
                        return@addSnapshotListener
                    }

                    val newPosts = mutableListOf<Post>()
                    for (doc in snapshots) {
                        val id = doc.id
                        val authEmail = doc.getString("authorEmail") ?: ""
                        val authUid = doc.getString("authorUid") ?: ""
                        val username = doc.getString("username") ?: "@usuario"
                        val description = doc.getString("description") ?: ""
                        val imageUrl = doc.getString("imageUrl") ?: ""
                        val likes = doc.getLong("likes")?.toInt() ?: 0
                        
                        val likedByRaw = doc.get("likedBy") as? List<*>
                        val likedBy = likedByRaw?.filterIsInstance<String>()?.toMutableList() ?: mutableListOf()
                        val isLiked = likedBy.contains(com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email)

                        newPosts.add(Post(id, authEmail, authUid, username, description, imageUrl, likes, isLiked, likedBy))
                    }
                    
                    postsList.clear()
                    postsList.addAll(newPosts)
                    if (!isFinishing && !isDestroyed) {
                        postAdapter.notifyDataSetChanged()
                    }
                }
            }
    }

    private fun createPokemonMockPosts() {
        val mockPosts = listOf(
            hashMapOf(
                "username" to "@ash_ketchum",
                "authorEmail" to "ash@nexo.com",
                "authorUid" to "mock_ash_uid",
                "description" to "¡Por fin conseguí mi primera medalla en Ciudad Plateada! Pikachu estuvo increíble. ⚡🏆",
                "imageUrl" to "",
                "likes" to 150,
                "timestamp" to com.google.firebase.Timestamp.now()
            ),
            hashMapOf(
                "username" to "@profesor_oak",
                "authorEmail" to "oak@nexo.com",
                "authorUid" to "mock_oak_uid",
                "description" to "Recordatorio para todos los entrenadores: la Pokédex no se completa sola. ¡Salgan a explorar! 🌍🔬",
                "imageUrl" to "",
                "likes" to 324,
                "timestamp" to com.google.firebase.Timestamp.now()
            ),
            hashMapOf(
                "username" to "@misty_water",
                "authorEmail" to "misty@nexo.com",
                "authorUid" to "mock_misty_uid",
                "description" to "¿Alguien ha visto mi bicicleta? Un chico con un Pikachu me la rompió hace unos días... 🚲💧",
                "imageUrl" to "",
                "likes" to 89,
                "timestamp" to com.google.firebase.Timestamp.now()
            ),
             hashMapOf(
                "username" to "@equipo_rocket",
                "authorEmail" to "rocket@nexo.com",
                "authorUid" to "mock_rocket_uid",
                "description" to "¡Prepárense para los problemas! Y más vale que teman... 🚀🌟",
                "imageUrl" to "",
                "likes" to 10,
                "timestamp" to com.google.firebase.Timestamp.now()
            )
        )

        for (post in mockPosts) {
            db.collection("posts").add(post)
        }
    }
}