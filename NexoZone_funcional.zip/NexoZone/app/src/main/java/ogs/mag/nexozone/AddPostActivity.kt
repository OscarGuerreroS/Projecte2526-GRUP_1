package ogs.mag.nexozone

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AddPostActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private var selectedImageUri: Uri? = null
    private lateinit var ivPostImage: ImageView

    // Lanzador para la galería
    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            ivPostImage.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_post)
        
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        ivPostImage = findViewById(R.id.ivPostImage)

        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.btnSelectImage).setOnClickListener {
            // Abrir selector de imágenes
            selectImageLauncher.launch("image/*")
        }

        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val caption = findViewById<EditText>(R.id.etCaption).text.toString().trim()
            if (caption.isNotEmpty()) {
                sharePost(caption)
            } else {
                Toast.makeText(this, "Escribe una descripción", Toast.LENGTH_SHORT).show()
            }
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_add

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_add -> true
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun sharePost(description: String) {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(this, "Debes iniciar sesión para publicar", Toast.LENGTH_SHORT).show()
            return
        }
        val userEmail = user.email ?: ""
        val userUid = user.uid

        db.collection("users").document(userUid).get()
            .addOnSuccessListener { doc ->
                val username = if (doc.exists() && !doc.getString("username").isNullOrEmpty()) {
                    "@" + doc.getString("username")
                } else {
                    "@" + userEmail.substringBefore("@")
                }

                // Asegurar persistencia de la imagen copiándola a memoria local
                var finalImageUrl = selectedImageUri?.toString() ?: ""
                if (selectedImageUri != null && finalImageUrl.startsWith("content://")) {
                    try {
                        val inputStream = contentResolver.openInputStream(selectedImageUri!!)
                        val file = java.io.File(filesDir, "post_img_${System.currentTimeMillis()}.jpg")
                        val outputStream = java.io.FileOutputStream(file)
                        inputStream?.copyTo(outputStream)
                        inputStream?.close()
                        outputStream.close()
                        finalImageUrl = Uri.fromFile(file).toString()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                val postData = hashMapOf(
                    "authorEmail" to userEmail,
                    "authorUid" to userUid,
                    "username" to username,
                    "description" to description,
                    "likes" to 0,
                    "imageUrl" to finalImageUrl,
                    "timestamp" to com.google.firebase.Timestamp.now()
                )

                db.collection("posts")
                    .add(postData)
                    .addOnSuccessListener {
                        Toast.makeText(this, "¡Publicación compartida!", Toast.LENGTH_LONG).show()
                        startActivity(Intent(this, HomeActivity::class.java))
                        finish()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error obteniendo usuario", Toast.LENGTH_SHORT).show()
            }
    }
}
