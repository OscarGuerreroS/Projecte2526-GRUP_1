package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Referencias
        val usernameText = findViewById<TextView>(R.id.usernameText)
        val bioText = findViewById<TextView>(R.id.bioText)
        val profileImage = findViewById<ImageView>(R.id.profileImage)

        // Configuración de ejemplo
        usernameText.text = "carlos_dev"
        bioText.text = "Desarrollador en NexoZone. Construyendo el futuro."

        // En ProfileActivity.kt, dentro de onCreate:
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_profile // CAMBIA ESTO

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_add -> {
                    // Si creas la actividad, descomenta esta línea:
                    // startActivity(Intent(this, AddPostActivity::class.java))
                    true
                }
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }
    }
}