package ogs.mag.nexozone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

data class Post(
    val username: String,
    val description: String,
    var likes: Int,
    var isLiked: Boolean = false
)

class PostAdapter(private val posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val username: TextView = view.findViewById(R.id.textUsername)
        val description: TextView = view.findViewById(R.id.textDescription)
        val likesCount: TextView = view.findViewById(R.id.textLikesCount)
        val buttonLike: TextView = view.findViewById(R.id.buttonLike)
        val buttonComment: TextView = view.findViewById(R.id.buttonComment)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        // CORRECCIÓN: Se usa R.layout.item_post en lugar de R.id.item_post
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        val context = holder.itemView.context

        holder.username.text = post.username
        holder.description.text = post.description

        // Uso de placeholders desde strings.xml
        holder.likesCount.text = context.getString(R.string.likes_placeholder, post.likes)
        holder.buttonLike.text = if (post.isLiked)
            context.getString(R.string.liked_icon)
        else context.getString(R.string.like_icon)

        holder.buttonLike.setOnClickListener {
            post.isLiked = !post.isLiked
            if (post.isLiked) {
                post.likes++
                holder.buttonLike.text = context.getString(R.string.liked_icon)
            } else {
                post.likes--
                holder.buttonLike.text = context.getString(R.string.like_icon)
            }
            holder.likesCount.text = context.getString(R.string.likes_placeholder, post.likes)
        }

        holder.buttonComment.setOnClickListener {
            Toast.makeText(context, "Comentar publicación", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount() = posts.size
}