package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Configurar el RecyclerView
        val dummyPosts = listOf(
            Post("@carlos_dev", "¡Trabajando en la nueva app NexoZone! El diseño está quedando genial. 🚀", 14),
            Post("@ana_foto", "Ayer paseando por la ciudad. Increíbles vistas.", 102),
            Post("@gamer_zone", "Alguien para unas partidas esta noche? 🎮", 5),
            Post("@nexozone_oficial", "¡Bienvenidos a la fase beta de la aplicación! Déjennos sus comentarios.", 250)
        )

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewFeed)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = PostAdapter(dummyPosts)

        // 2. Configurar el Menú Inferior (AHORA DENTRO DEL ONCREATE)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_home // Marca inicio como seleccionado

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_add -> {
                    // Si creas la actividad, descomenta esta línea:
                    // startActivity(Intent(this, AddPostActivity::class.java))
                    true
                }
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }
    }
}