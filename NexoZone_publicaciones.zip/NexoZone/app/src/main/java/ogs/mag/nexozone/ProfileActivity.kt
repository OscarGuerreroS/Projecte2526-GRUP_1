package ogs.mag.nexozone

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProfileActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val usernameText = findViewById<TextView>(R.id.usernameText)
        val bioText = findViewById<TextView>(R.id.bioText)
        val profileImage = findViewById<ImageView>(R.id.profileImage)
        val btnEditProfile = findViewById<Button>(R.id.btnEditProfile)

        btnEditProfile.setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }

        val btnLogout = findViewById<android.widget.ImageButton>(R.id.btnLogout)
        btnLogout.setOnClickListener {
            auth.signOut()
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        // Cargar datos del usuario
        val user = auth.currentUser
        if (user != null) {
            val uid = user.uid
            val myEmail = user.email ?: "anonimo"
            
            db.collection("users").document(uid)
                .addSnapshotListener { snapshot, e ->
                    if (e != null) {
                        android.util.Log.e("Profile", "Error cargando perfil: ${e.message}")
                        return@addSnapshotListener
                    }

                    if (snapshot != null && snapshot.exists()) {
                        val name = snapshot.getString("username") ?: myEmail.substringBefore("@")
                        val bio = snapshot.getString("bio") ?: "¡Hola! Estoy usando NexoZone."
                        val imageUrl = snapshot.getString("imageUrl") ?: ""

                        usernameText.text = "@$name"
                        bioText.text = bio

                        if (imageUrl.isNotEmpty()) {
                            try {
                                profileImage.setImageURI(Uri.parse(imageUrl))
                            } catch (e: Exception) {}
                        }
                    } else {
                        usernameText.text = "@${myEmail.substringBefore("@")}"
                        bioText.text = "¡Añade una biografía desde Editar Perfil!"
                    }
                }
        } else {
            usernameText.text = "@invitado"
            bioText.text = "No has iniciado sesión."
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_profile

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddPostActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_profile -> true
                else -> false
            }
        }
    }
}