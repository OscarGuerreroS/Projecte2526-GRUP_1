package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PurchaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_purchase)
        
        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<android.widget.ImageView>(R.id.btnCart)?.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
        findViewById<android.widget.Button>(R.id.btnViewCart)?.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }

        val rvProducts = findViewById<RecyclerView>(R.id.recyclerViewProducts)
        val testProducts = listOf(
            Product("Consola Nintendo Switch OLED", "La mejor consola híbrida con pantalla OLED de 7 pulgadas.", 349.99),
            Product("Pase de Batalla - Temporada X", "Desbloquea 100 niveles de recompensas épicas.", 9.99),
            Product("Pokéball Plus", "Atrapa Pokémon en la vida real y llévalos a todas partes.", 49.50),
            Product("Figura Amiibo Pikachu", "Figura interactiva para juegos de Nintendo.", 15.00)
        )
        rvProducts.layoutManager = LinearLayoutManager(this)
        rvProducts.adapter = ProductAdapter(testProducts)

        // Configurar el Menú Inferior
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_shop

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_add -> {
                    startActivity(Intent(this, AddPostActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_shop -> true
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                else -> false
            }
        }
    }
}