package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import ogs.mag.nexozone.databinding.ActivityCheckoutBinding

class CheckoutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCheckoutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnConfirmPayment.setOnClickListener {
            // Simulamos el pago exitoso
            val intent = Intent(this, PaymentSuccessActivity::class.java)
            // Agregamos flags para limpiar el historial y que "atrás" desde success vuelva al home o similar
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish() // Cerramos esta
        }
    }
}
