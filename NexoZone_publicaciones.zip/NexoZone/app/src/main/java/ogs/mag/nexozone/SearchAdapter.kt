package ogs.mag.nexozone

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ogs.mag.nexozone.databinding.ItemSearchResultBinding

data class SearchResultItem(val name: String, val tag: String, val isUser: Boolean = false)

class SearchAdapter(private var items: List<SearchResultItem>, private val onItemClick: (SearchResultItem) -> Unit) : RecyclerView.Adapter<SearchAdapter.SearchViewHolder>() {

    class SearchViewHolder(val binding: ItemSearchResultBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchViewHolder {
        val binding = ItemSearchResultBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SearchViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SearchViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvItemName.text = item.name
        holder.binding.tvItemTag.text = item.tag
        
        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<SearchResultItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
