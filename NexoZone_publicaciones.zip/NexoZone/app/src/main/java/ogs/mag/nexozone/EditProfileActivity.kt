package ogs.mag.nexozone

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class EditProfileActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private var selectedImageUri: Uri? = null
    private lateinit var ivProfileImage: ImageView

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            ivProfileImage.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_edit_profile)
        
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        ivProfileImage = findViewById(R.id.ivEditProfileImage)

        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<androidx.cardview.widget.CardView>(R.id.editImageCard).setOnClickListener {
            // Abrir selector de la galería
            selectImageLauncher.launch("image/*")
        }

        val etUsername = findViewById<EditText>(R.id.etEditUsername)
        val etBio = findViewById<EditText>(R.id.etEditBio)

        val user = auth.currentUser
        if (user != null) {
            val userUid = user.uid
            val userEmail = user.email ?: ""
            
            db.collection("users").document(userUid).get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        val currentUsername = doc.getString("username") ?: ""
                        if (currentUsername.isNotEmpty()) {
                            etUsername.setText(currentUsername)
                        } else {
                            etUsername.setText(userEmail.substringBefore("@"))
                        }
                        
                        etBio.setText(doc.getString("bio") ?: "")
                        
                        val imgUrl = doc.getString("imageUrl") ?: ""
                        if (imgUrl.isNotEmpty()) {
                            try {
                                ivProfileImage.setImageURI(Uri.parse(imgUrl))
                                selectedImageUri = Uri.parse(imgUrl)
                            } catch (e: Exception) {}
                        }
                    }
                }
        }

        findViewById<Button>(R.id.btnSaveProfile).setOnClickListener {
            val user = auth.currentUser
            if (user == null) {
                Toast.makeText(this, "Debes iniciar sesión", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val userUid = user.uid
            val userEmail = user.email ?: ""
            val username = etUsername.text.toString().trim()
            val bio = etBio.text.toString().trim()

            if (username.isEmpty()) {
                Toast.makeText(this, "Pon un nombre de usuario", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            var finalImageUrl = selectedImageUri?.toString() ?: ""
            if (selectedImageUri != null && finalImageUrl.startsWith("content://")) {
                try {
                    val inputStream = contentResolver.openInputStream(selectedImageUri!!)
                    val file = java.io.File(filesDir, "profile_pic_${userUid}.jpg")
                    val outputStream = java.io.FileOutputStream(file)
                    inputStream?.copyTo(outputStream)
                    inputStream?.close()
                    outputStream.close()
                    finalImageUrl = Uri.fromFile(file).toString()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val userData = hashMapOf(
                "username" to username,
                "bio" to bio,
                "imageUrl" to finalImageUrl
            )

            // Comprobar si el username ya existe en otro documento (excluyendo el mío)
            db.collection("users").whereEqualTo("username", username).get()
                .addOnSuccessListener { query ->
                    val isTaken = query.documents.any { it.id != userUid }
                    
                    if (isTaken) {
                        Toast.makeText(this, "Ese nombre de usuario ya está en uso", Toast.LENGTH_SHORT).show()
                    } else {
                        // Guardar datos en mi UID
                        db.collection("users").document(userUid)
                            .set(userData, com.google.firebase.firestore.SetOptions.merge())
                            .addOnSuccessListener {
                                Toast.makeText(this, "¡Perfil actualizado!", Toast.LENGTH_SHORT).show()
                                finish()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error validando usuario: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }
}