package ogs.mag.nexozone

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.ByteArrayOutputStream

class AddPostActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private var selectedImageUri: Uri? = null
    private lateinit var ivPostImage: ImageView

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            ivPostImage.setImageURI(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_post)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        ivPostImage = findViewById(R.id.ivPostImage)

        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<Button>(R.id.btnSelectImage).setOnClickListener {
            selectImageLauncher.launch("image/*")
        }

        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val caption = findViewById<EditText>(R.id.etCaption).text.toString().trim()
            if (caption.isNotEmpty()) {
                sharePost(caption)
            } else {
                Toast.makeText(this, "Escribe una descripcion", Toast.LENGTH_SHORT).show()
            }
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_add

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_chat -> {
                    startActivity(Intent(this, ChatPageActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_add -> true
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun sharePost(description: String) {
        val user = auth.currentUser
        if (user == null) {
            Toast.makeText(this, "Debes iniciar sesion para publicar", Toast.LENGTH_SHORT).show()
            return
        }

        val userEmail = user.email ?: ""
        val userUid = user.uid

        db.collection("users").document(userUid).get()
            .addOnSuccessListener { doc ->
                val username = if (doc.exists() && !doc.getString("username").isNullOrEmpty()) {
                    "@" + doc.getString("username")
                } else {
                    "@" + userEmail.substringBefore("@")
                }

                val imageUri = selectedImageUri
                if (imageUri != null) {
                    val imageBase64 = encodeImageToBase64(imageUri)
                    if (imageBase64 == null) {
                        Toast.makeText(this, "No se pudo preparar la imagen", Toast.LENGTH_LONG).show()
                        return@addOnSuccessListener
                    }

                    createPostDocument(
                        authorEmail = userEmail,
                        authorUid = userUid,
                        username = username,
                        description = description,
                        imageUrl = "",
                        imagePath = "",
                        imageBase64 = imageBase64
                    )
                } else {
                    createPostDocument(
                        authorEmail = userEmail,
                        authorUid = userUid,
                        username = username,
                        description = description,
                        imageUrl = "",
                        imagePath = "",
                        imageBase64 = ""
                    )
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error obteniendo usuario", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createPostDocument(
        authorEmail: String,
        authorUid: String,
        username: String,
        description: String,
        imageUrl: String,
        imagePath: String,
        imageBase64: String
    ) {
        val postData = hashMapOf(
            "authorEmail" to authorEmail,
            "authorUid" to authorUid,
            "username" to username,
            "description" to description,
            "likes" to 0,
            "imageUrl" to imageUrl,
            "imagePath" to imagePath,
            "imageBase64" to imageBase64,
            "timestamp" to com.google.firebase.Timestamp.now()
        )

        db.collection("posts")
            .add(postData)
            .addOnSuccessListener {
                Toast.makeText(this, "Publicacion compartida", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun encodeImageToBase64(imageUri: Uri): String? {
        return try {
            contentResolver.openInputStream(imageUri)?.use { inputStream ->
                val originalBitmap = BitmapFactory.decodeStream(inputStream) ?: return null
                val resizedBitmap = resizeBitmapIfNeeded(originalBitmap, 960)
                val outputStream = ByteArrayOutputStream()
                resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 65, outputStream)
                val imageBytes = outputStream.toByteArray()

                if (imageBytes.size > 700_000) {
                    Toast.makeText(this, "La imagen es demasiado grande, elige una mas ligera", Toast.LENGTH_LONG).show()
                    return null
                }

                Base64.encodeToString(imageBytes, Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            android.util.Log.e("AddPostActivity", "Error convirtiendo imagen: ${e.message}", e)
            null
        }
    }

    private fun resizeBitmapIfNeeded(bitmap: Bitmap, maxSize: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val largestSide = maxOf(width, height)

        if (largestSide <= maxSize) return bitmap

        val scale = maxSize.toFloat() / largestSide.toFloat()
        val resizedWidth = (width * scale).toInt()
        val resizedHeight = (height * scale).toInt()
        return Bitmap.createScaledBitmap(bitmap, resizedWidth, resizedHeight, true)
    }
}
