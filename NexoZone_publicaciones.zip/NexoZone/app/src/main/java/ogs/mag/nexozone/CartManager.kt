package ogs.mag.nexozone

object CartManager {
    val items = mutableListOf<CartItem>()
}
