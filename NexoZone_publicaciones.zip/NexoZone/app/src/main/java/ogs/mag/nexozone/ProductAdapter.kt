package ogs.mag.nexozone

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

data class Product(val title: String, val description: String, val price: Double)

class ProductAdapter(private val products: List<Product>) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    class ProductViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.tvProductTitle)
        val price: TextView = view.findViewById(R.id.tvProductPrice)
        val desc: TextView = view.findViewById(R.id.tvProductDesc)
        val btnAdd: Button = view.findViewById(R.id.btnAddCart)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]
        holder.title.text = product.title
        holder.desc.text = product.description
        holder.price.text = String.format("%.2f €", product.price)

        holder.btnAdd.setOnClickListener {
            CartManager.items.add(CartItem(product.title, product.price))
            Toast.makeText(holder.itemView.context, "${product.title} añadido", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount() = products.size
}
