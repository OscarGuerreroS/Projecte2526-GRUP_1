package ogs.mag.nexozone

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import ogs.mag.nexozone.databinding.ItemNotificationBinding

data class NotificationItem(val text: String, val time: String)

class NotificationsAdapter(private var items: List<NotificationItem>) : RecyclerView.Adapter<NotificationsAdapter.NotificationViewHolder>() {

    class NotificationViewHolder(val binding: ItemNotificationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
        val binding = ItemNotificationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NotificationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvNotifText.text = item.text
        holder.binding.tvNotifTime.text = item.time
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<NotificationItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
