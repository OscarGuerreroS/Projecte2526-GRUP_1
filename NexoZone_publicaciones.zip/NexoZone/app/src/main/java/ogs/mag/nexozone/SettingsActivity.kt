package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import ogs.mag.nexozone.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnPrivacy.setOnClickListener {
            Toast.makeText(this, "Privacidad: Próximamente", Toast.LENGTH_SHORT).show()
        }

        binding.btnSecurity.setOnClickListener {
            Toast.makeText(this, "Seguridad: Próximamente", Toast.LENGTH_SHORT).show()
        }

        binding.btnPreferences.setOnClickListener {
            Toast.makeText(this, "Preferencias: Próximamente", Toast.LENGTH_SHORT).show()
        }

        binding.btnLogout.setOnClickListener {
            // Ir a Login
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
