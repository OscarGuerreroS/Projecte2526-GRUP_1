package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Borra la línea de FirebaseApp.initializeApp(this)
        auth = FirebaseAuth.getInstance()

        // Referencias a los IDs (que ya comprobamos que coinciden con tu XML)
        val emailEditText = findViewById<EditText>(R.id.editTextText7)
        val passwordEditText = findViewById<EditText>(R.id.editTextText9)
        val loginButton = findViewById<Button>(R.id.loginButton2)
        // 4. Configurar el evento de clic
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                loginUser(email, password)
            }
        }
    }

    private fun loginUser(email: String, password: String) {
        // Firebase Auth usa email y contraseña
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Inicio de sesión correcto
                    val user = auth.currentUser
                    Toast.makeText(this, "Bienvenido: ${user?.email}", Toast.LENGTH_SHORT).show()

                    // Redirigir a MainActivity
                    val intent = Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                    finish() // Para que no pueda volver al login con el botón de atrás
                } else {
                    // Error: Usuario no existe, contraseña mal o falta de internet
                    val errorMessage = task.exception?.message ?: "Error desconocido"
                    Toast.makeText(this, "Error de autenticación: $errorMessage", Toast.LENGTH_LONG).show()
                }
            }
    }
}