package ogs.mag.nexozone

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import ogs.mag.nexozone.databinding.ActivityNotificationsBinding
import java.text.SimpleDateFormat
import java.util.Locale

class NotificationsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationsBinding
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var adapter: NotificationsAdapter
    private val notificationsList = mutableListOf<NotificationItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        
        adapter = NotificationsAdapter(notificationsList)
        binding.rvNotifications.layoutManager = LinearLayoutManager(this)
        binding.rvNotifications.adapter = adapter

        loadNotifications()

        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadNotifications() {
        val uid = auth.currentUser?.uid ?: return
        
        db.collection("users").document(uid).collection("notifications")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null || snapshots == null) return@addSnapshotListener
                
                val newList = mutableListOf<NotificationItem>()
                val sdf = SimpleDateFormat("HH:mm, dd MMM", Locale.getDefault())
                
                for (doc in snapshots) {
                    val text = doc.getString("text") ?: ""
                    val timestamp = doc.getTimestamp("timestamp")
                    val time = if (timestamp != null) sdf.format(timestamp.toDate()) else ""
                    newList.add(NotificationItem(text, time))
                    
                    // Marcar como leída
                    if (doc.getBoolean("isRead") == false) {
                        doc.reference.update("isRead", true)
                    }
                }
                adapter.updateItems(newList)
            }
    }
}
