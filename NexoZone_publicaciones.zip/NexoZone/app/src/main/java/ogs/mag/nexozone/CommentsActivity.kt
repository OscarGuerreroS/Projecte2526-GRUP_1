package ogs.mag.nexozone

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class CommentsActivity : AppCompatActivity() {

    private lateinit var rvComments: RecyclerView
    private lateinit var etNewComment: EditText
    private lateinit var btnSendComment: Button
    
    private val commentsList = mutableListOf<Comment>()
    private lateinit var commentAdapter: CommentAdapter
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    private var postId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comments)

        postId = intent.getStringExtra("POST_ID") ?: ""
        if (postId.isEmpty() || postId.startsWith("mock")) {
            Toast.makeText(this, "Las publicaciones de prueba o vacías no admiten comentarios.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        rvComments = findViewById(R.id.rvComments)
        etNewComment = findViewById(R.id.etNewComment)
        btnSendComment = findViewById(R.id.btnSendComment)

        commentAdapter = CommentAdapter(commentsList)
        rvComments.layoutManager = LinearLayoutManager(this)
        rvComments.adapter = commentAdapter

        loadComments()
        
        findViewById<android.widget.ImageButton>(R.id.btnBackComments).setOnClickListener {
            finish()
        }

        btnSendComment.setOnClickListener {
            val text = etNewComment.text.toString().trim()
            if (text.isNotEmpty()) {
                sendComment(text)
            }
        }
    }

    private fun loadComments() {
        db.collection("posts").document(postId).collection("comments")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    commentsList.clear()
                    for (doc in snapshots) {
                        val username = doc.getString("username") ?: "@usuario"
                        val text = doc.getString("text") ?: ""
                        commentsList.add(Comment(username, text))
                    }
                    commentAdapter.notifyDataSetChanged()
                    if (commentsList.isNotEmpty()) {
                        rvComments.smoothScrollToPosition(commentsList.size - 1)
                    }
                }
            }
    }

    private fun sendComment(text: String) {
        val user = auth.currentUser
        val email = user?.email
        val uid = user?.uid
        if (email == null || uid == null) {
            Toast.makeText(this, "Debes iniciar sesión para comentar", Toast.LENGTH_SHORT).show()
            return
        }

        btnSendComment.isEnabled = false

        db.collection("users").document(uid).get().addOnSuccessListener { doc ->
            val username = if (doc.exists() && !doc.getString("username").isNullOrEmpty()) {
                "@" + doc.getString("username")
            } else {
                "@" + email.substringBefore("@")
            }

            val commentData = hashMapOf(
                "username" to username,
                "text" to text,
                "timestamp" to com.google.firebase.Timestamp.now()
            )

            db.collection("posts").document(postId).collection("comments")
                .add(commentData)
                .addOnSuccessListener {
                    val authorEmail = intent.getStringExtra("AUTHOR_EMAIL") ?: ""
                    val authorUid = intent.getStringExtra("AUTHOR_UID") ?: ""
                    
                    if (authorUid.isNotEmpty() && authorUid != uid) {
                        // Buscar descripción del post para el contexto
                        db.collection("posts").document(postId).get().addOnSuccessListener { postDoc ->
                            val fullDesc = postDoc.getString("description") ?: ""
                            val postPreview = if (fullDesc.length > 20) fullDesc.take(20) + "..." else fullDesc
                            
                            val notifData = hashMapOf(
                                "text" to "$username comentó en tu post '$postPreview': $text",
                                "type" to "COMMENT",
                                "isRead" to false,
                                "timestamp" to com.google.firebase.Timestamp.now()
                            )
                            db.collection("users").document(authorUid)
                                .collection("notifications").add(notifData)
                        }
                    } else if (authorEmail.isNotEmpty() && authorEmail != email && authorUid.isEmpty()) {
                        // Fallback temporal si el post es muy antiguo y no tiene UID
                        android.util.Log.w("Comments", "El post no tiene UID, no se envía notificación.")
                    }

                    etNewComment.text.clear()
                    btnSendComment.isEnabled = true
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al enviar", Toast.LENGTH_SHORT).show()
                    btnSendComment.isEnabled = true
                }
        }.addOnFailureListener {
            btnSendComment.isEnabled = true
        }
    }
}
