package ogs.mag.nexozone

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class OtherUserProfileActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_other_user_profile)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val usernameText = findViewById<TextView>(R.id.usernameText)
        val bioText = findViewById<TextView>(R.id.bioText)
        val profileImage = findViewById<ImageView>(R.id.profileImage)
        val btnMessage = findViewById<Button>(R.id.btnMessage)
        val btnBack = findViewById<ImageButton>(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        val targetUsername = intent.getStringExtra("USERNAME") ?: ""

        if (targetUsername.isEmpty() || targetUsername.startsWith("@")) {
            Toast.makeText(this, "Usuario no válido", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        usernameText.text = "@$targetUsername"

        // Buscar el usuario por su username
        db.collection("users").whereEqualTo("username", targetUsername).get()
            .addOnSuccessListener { query ->
                if (!query.isEmpty) {
                    val doc = query.documents[0]
                    val bio = doc.getString("bio") ?: "¡Hola! Estoy usando NexoZone."
                    val imageUrl = doc.getString("imageUrl") ?: ""

                    bioText.text = bio

                    if (imageUrl.isNotEmpty()) {
                        try {
                            profileImage.setImageURI(Uri.parse(imageUrl))
                        } catch (e: Exception) {}
                    }
                } else {
                    bioText.text = "Este usuario aún no configuró su biografía."
                }
            }
            .addOnFailureListener {
                bioText.text = "Error al cargar el perfil."
            }

        btnMessage.setOnClickListener {
            val intent = Intent(this, ConversationActivity::class.java)
            // ConversationActivity espera la Key "username" en minúscula
            intent.putExtra("username", "@$targetUsername")
            startActivity(intent)
        }
    }
}
