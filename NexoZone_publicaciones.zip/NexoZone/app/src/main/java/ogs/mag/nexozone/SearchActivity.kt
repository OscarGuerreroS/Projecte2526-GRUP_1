package ogs.mag.nexozone

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.firestore.FirebaseFirestore
import ogs.mag.nexozone.databinding.ActivitySearchBinding

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private lateinit var db: FirebaseFirestore
    private lateinit var adapter: SearchAdapter
    private var isSearchingUsers = false

    private val gamesList = listOf(
        SearchResultItem("Valorant", "Juego FPS", false),
        SearchResultItem("League of Legends", "MOBA", false),
        SearchResultItem("Minecraft", "Supervivencia", false),
        SearchResultItem("Overwatch 2", "Juego FPS", false),
        SearchResultItem("Counter Strike 2", "Juego FPS", false),
        SearchResultItem("Diablo IV", "Juego de Rol", false)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = FirebaseFirestore.getInstance()
        binding.rvSearchResults.layoutManager = LinearLayoutManager(this)
        
        adapter = SearchAdapter(gamesList) { item ->
            if (item.isUser) {
                val intent = Intent(this, OtherUserProfileActivity::class.java)
                intent.putExtra("USERNAME", item.name.removePrefix("@"))
                startActivity(intent)
            } else {
                Toast.makeText(this, "Accediendo a comunidad de: ${item.name}", Toast.LENGTH_SHORT).show()
            }
        }
        binding.rvSearchResults.adapter = adapter

        binding.etSearchQuery.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                performSearch(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnFilterGames.setOnClickListener {
            isSearchingUsers = false
            binding.btnFilterGames.setTextColor(Color.parseColor("#FF007F"))
            binding.btnFilterUsers.setTextColor(Color.WHITE)
            performSearch(binding.etSearchQuery.text.toString())
        }

        binding.btnFilterUsers.setOnClickListener {
            isSearchingUsers = true
            binding.btnFilterUsers.setTextColor(Color.parseColor("#FF007F"))
            binding.btnFilterGames.setTextColor(Color.WHITE)
            performSearch(binding.etSearchQuery.text.toString())
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun performSearch(queryText: String) {
        val q = queryText.trim()
        
        if (!isSearchingUsers) {
            val qLower = q.lowercase()
            val filteredGames = if (qLower.isEmpty()) gamesList else gamesList.filter { it.name.lowercase().contains(qLower) }
            adapter.updateItems(filteredGames)
        } else {
            if (q.isEmpty()) {
                adapter.updateItems(emptyList())
                return
            }
            
            db.collection("users")
                .whereGreaterThanOrEqualTo("username", q)
                .whereLessThanOrEqualTo("username", q + "\uf8ff")
                .get()
                .addOnSuccessListener { result ->
                    val foundUsers = mutableListOf<SearchResultItem>()
                    for (doc in result) {
                        val un = doc.getString("username") ?: continue
                        foundUsers.add(SearchResultItem("@$un", "Usuario", true))
                    }
                    adapter.updateItems(foundUsers)
                }
        }
    }
}
