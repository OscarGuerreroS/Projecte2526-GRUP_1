package ogs.mag.nexozone

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Locale

class ChatPageActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private val chatsList = mutableListOf<Chat>()
    private lateinit var chatAdapter: ChatAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_chat_page)
        
        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewChat)
        recyclerView.layoutManager = LinearLayoutManager(this)
        chatAdapter = ChatAdapter(chatsList) { chat ->
            val intent = Intent(this, ConversationActivity::class.java)
            intent.putExtra("username", chat.username)
            startActivity(intent)
        }
        recyclerView.adapter = chatAdapter

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_chat

        loadRecentChats(bottomNav)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_chat -> true
                R.id.nav_add -> {
                    startActivity(Intent(this, AddPostActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_shop -> {
                    startActivity(Intent(this, PurchaseActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }
                else -> false
            }
        }
    }

    private fun loadRecentChats(bottomNav: BottomNavigationView) {
        val uid = auth.currentUser?.uid ?: return
        
        db.collection("users").document(uid).collection("recentChats")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    if (auth.currentUser != null) {
                        Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                    return@addSnapshotListener
                }
                if (snapshots == null) return@addSnapshotListener
                
                chatsList.clear()
                var totalUnread = 0
                val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                
                // 1. Cargar Mensajes Reales del Servidor
                for (doc in snapshots) {
                    val username = doc.getString("username") ?: "Desconocido"
                    var lastMessage = doc.getString("lastMessage") ?: ""
                    if (lastMessage.isEmpty()) lastMessage = "Pulsa para chatear..."
                    
                    val unreadCount = doc.getLong("unreadCount")?.toInt() ?: 0
                    val timestamp = doc.getTimestamp("timestamp")
                    val time = if (timestamp != null) sdf.format(timestamp.toDate()) else ""
                    
                    totalUnread += unreadCount
                    chatsList.add(Chat(username, lastMessage, time, unreadCount))
                }

                // 2. Añadir Mensajes de Ejemplo (para que nunca esté vacío)
                val dummyMessages = listOf(
                    Chat("Carlos Dev", "¡Hey! ¿Cómo va el proyecto?", "12:30 PM", 0),
                    Chat("Ana Foto", "Te mandé las imágenes de ayer.", "11:15 AM", 1),
                    Chat("Gamer Zone", "¿Sale esa partida hoy?", "Ayer", 0),
                    Chat("NexoZone Oficial", "Bienvenido a la comunidad.", "Lunes", 0)
                )
                
                // Solo añadimos los de ejemplo que no coincidan con usuarios reales ya cargados
                for (dummy in dummyMessages) {
                    if (chatsList.none { it.username == dummy.username }) {
                        chatsList.add(dummy)
                    }
                }
                
                chatAdapter.notifyDataSetChanged()
                
                // Actualizar el globo del menú inferior
                if (totalUnread > 0) {
                    val badge = bottomNav.getOrCreateBadge(R.id.nav_chat)
                    badge.isVisible = true
                    badge.number = totalUnread
                } else {
                    bottomNav.removeBadge(R.id.nav_chat)
                }
            }
    }
}