package ogs.mag.nexozone

import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.net.URL
import java.util.concurrent.Executors

data class Post(
    val id: String,
    val authorEmail: String,
    val authorUid: String,
    val username: String,
    val description: String,
    val imageUrl: String,
    val imagePath: String = "",
    val imageBase64: String = "",
    var likes: Int,
    var isLiked: Boolean = false,
    var likedBy: MutableList<String> = mutableListOf()
)

class PostAdapter(private val posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    private val imageExecutor = Executors.newCachedThreadPool()
    private val imageCache = object : LruCache<String, android.graphics.Bitmap>(20) {}

    class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val username: TextView = view.findViewById(R.id.textUsername)
        val description: TextView = view.findViewById(R.id.textDescription)
        val imagePost: android.widget.ImageView = view.findViewById(R.id.imagePost)
        val likesCount: TextView = view.findViewById(R.id.textLikesCount)
        val buttonLike: TextView = view.findViewById(R.id.buttonLike)
        val buttonComment: TextView = view.findViewById(R.id.buttonComment)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        val context = holder.itemView.context

        holder.username.text = post.username
        holder.description.text = post.description

        if (post.imageBase64.isNotEmpty() || post.imagePath.isNotEmpty() || post.imageUrl.isNotEmpty()) {
            loadPostImage(holder, post)
        } else {
            holder.imagePost.visibility = View.GONE
            holder.imagePost.setImageDrawable(null)
        }

        holder.likesCount.text = context.getString(R.string.likes_placeholder, post.likes)
        holder.buttonLike.text = if (post.isLiked) {
            context.getString(R.string.liked_icon)
        } else {
            context.getString(R.string.like_icon)
        }

        holder.buttonLike.setOnClickListener {
            try {
                val user = FirebaseAuth.getInstance().currentUser ?: return@setOnClickListener
                val userUid = user.uid
                val userEmail = user.email ?: ""

                post.isLiked = !post.isLiked
                if (post.isLiked) {
                    post.likes++
                    if (!post.likedBy.contains(userEmail)) post.likedBy.add(userEmail)
                    holder.buttonLike.text = context.getString(R.string.liked_icon)
                } else {
                    post.likes--
                    post.likedBy.remove(userEmail)
                    holder.buttonLike.text = context.getString(R.string.like_icon)
                }
                holder.likesCount.text = context.getString(R.string.likes_placeholder, post.likes)

                if (post.id.isNotBlank() && !post.id.startsWith("mock")) {
                    val db = FirebaseFirestore.getInstance()
                    val postRef = db.collection("posts").document(post.id)

                    val updateTask = if (post.isLiked) {
                        postRef.update(
                            "likes", post.likes,
                            "likedBy", FieldValue.arrayUnion(userEmail)
                        )
                    } else {
                        postRef.update(
                            "likes", post.likes,
                            "likedBy", FieldValue.arrayRemove(userEmail)
                        )
                    }

                    updateTask.addOnSuccessListener {
                        if (post.isLiked && post.authorUid.isNotBlank() && post.authorUid != userUid) {
                            sendNotification(db, userUid, post.authorUid, post.description)
                        }
                    }.addOnFailureListener { e ->
                        android.util.Log.e("LikeDB", "Error al guardar: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("PostAdapter", "Cierre evitado en Like: ${e.message}", e)
                Toast.makeText(context, "Accion no disponible temporalmente", Toast.LENGTH_SHORT).show()
            }
        }

        holder.username.setOnClickListener {
            val intent = android.content.Intent(context, OtherUserProfileActivity::class.java)
            intent.putExtra("USERNAME", post.username.removePrefix("@"))
            context.startActivity(intent)
        }

        holder.buttonComment.setOnClickListener {
            val intent = android.content.Intent(context, CommentsActivity::class.java)
            intent.putExtra("POST_ID", post.id)
            intent.putExtra("AUTHOR_EMAIL", post.authorEmail)
            intent.putExtra("AUTHOR_UID", post.authorUid)
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = posts.size

    private fun loadPostImage(holder: PostViewHolder, post: Post) {
        val imagePath = post.imagePath
        val imageUrl = post.imageUrl
        val imageBase64 = post.imageBase64
        val context = holder.itemView.context
        val cacheKey = when {
            imageBase64.isNotEmpty() -> "b64_${post.id}"
            imagePath.isNotEmpty() -> imagePath
            else -> imageUrl
        }
        if (cacheKey.isEmpty()) {
            holder.imagePost.visibility = View.GONE
            holder.imagePost.setImageDrawable(null)
            return
        }

        val cachedBitmap = imageCache.get(cacheKey)
        if (cachedBitmap != null) {
            holder.imagePost.setImageBitmap(cachedBitmap)
            holder.imagePost.visibility = View.VISIBLE
            holder.imagePost.tag = cacheKey
            return
        }

        val imageUri = if (imageUrl.isNotEmpty()) Uri.parse(imageUrl) else null
        holder.imagePost.tag = cacheKey
        holder.imagePost.visibility = View.VISIBLE
        holder.imagePost.setImageDrawable(null)

        if (imageBase64.isNotEmpty()) {
            try {
                val bytes = Base64.decode(imageBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bitmap != null) {
                    imageCache.put(cacheKey, bitmap)
                    holder.imagePost.setImageBitmap(bitmap)
                    holder.imagePost.visibility = View.VISIBLE
                } else {
                    holder.imagePost.visibility = View.GONE
                    holder.imagePost.setImageDrawable(null)
                }
            } catch (e: Exception) {
                android.util.Log.w("PostAdapter", "Imagen Base64 no disponible: ${e.message}")
                holder.imagePost.visibility = View.GONE
                holder.imagePost.setImageDrawable(null)
            }
            return
        }

        if (imagePath.isNotEmpty()) {
            FirebaseStorage.getInstance().reference.child(imagePath)
                .getBytes(5L * 1024L * 1024L)
                .addOnSuccessListener { bytes ->
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (holder.imagePost.tag == cacheKey && bitmap != null) {
                        imageCache.put(cacheKey, bitmap)
                        holder.imagePost.setImageBitmap(bitmap)
                        holder.imagePost.visibility = View.VISIBLE
                    }
                }
                .addOnFailureListener { e ->
                    android.util.Log.w("PostAdapter", "No se pudo cargar desde Storage: ${e.message}")
                    if (imageUrl.isNotEmpty()) {
                        loadRemoteUrlImage(holder, imageUrl, cacheKey)
                    } else if (holder.imagePost.tag == cacheKey) {
                        holder.imagePost.visibility = View.GONE
                        holder.imagePost.setImageDrawable(null)
                    }
                }
            return
        }

        if (imageUri != null && (imageUri.scheme == "http" || imageUri.scheme == "https")) {
            loadRemoteUrlImage(holder, imageUrl, cacheKey)
            return
        }

        try {
            if (imageUri?.scheme == "content") {
                context.contentResolver.openInputStream(imageUri)?.use { inputStream ->
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    if (bitmap != null) {
                        imageCache.put(cacheKey, bitmap)
                        holder.imagePost.setImageBitmap(bitmap)
                        holder.imagePost.visibility = View.VISIBLE
                    } else {
                        holder.imagePost.visibility = View.GONE
                        holder.imagePost.setImageDrawable(null)
                    }
                }
            } else {
                holder.imagePost.visibility = View.GONE
                holder.imagePost.setImageDrawable(null)
            }
        } catch (e: Exception) {
            android.util.Log.w("PostAdapter", "Imagen no disponible: ${e.message}")
            holder.imagePost.visibility = View.GONE
            holder.imagePost.setImageDrawable(null)
        }
    }

    private fun loadRemoteUrlImage(holder: PostViewHolder, imageUrl: String, cacheKey: String) {
        imageExecutor.execute {
            try {
                val connection = URL(imageUrl).openConnection()
                connection.connectTimeout = 10_000
                connection.readTimeout = 10_000
                connection.getInputStream().use { inputStream ->
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    holder.imagePost.post {
                        if (holder.imagePost.tag == cacheKey && bitmap != null) {
                            imageCache.put(cacheKey, bitmap)
                            holder.imagePost.setImageBitmap(bitmap)
                            holder.imagePost.visibility = View.VISIBLE
                        }
                    }
                }
            } catch (e: Exception) {
                holder.imagePost.post {
                    if (holder.imagePost.tag == cacheKey) {
                        android.util.Log.w("PostAdapter", "Imagen remota no disponible: ${e.message}")
                        holder.imagePost.visibility = View.GONE
                        holder.imagePost.setImageDrawable(null)
                    }
                }
            }
        }
    }

    private fun sendNotification(db: FirebaseFirestore, fromUid: String, toUid: String, postDesc: String?) {
        if (fromUid.isBlank() || toUid.isBlank()) return

        db.collection("users").document(fromUid).get().addOnSuccessListener { doc ->
            if (doc.exists()) {
                try {
                    val myUn = doc.getString("username") ?: "Usuario"
                    val desc = postDesc ?: "un post"
                    val postPreview = if (desc.length > 20) desc.take(20) + "..." else desc

                    val notifData = hashMapOf(
                        "text" to "@$myUn le dio Like a tu post: '$postPreview'",
                        "type" to "LIKE",
                        "isRead" to false,
                        "timestamp" to com.google.firebase.Timestamp.now()
                    )

                    db.collection("users").document(toUid)
                        .collection("notifications").add(notifData)
                } catch (e: Exception) {
                    android.util.Log.e("Notif", "Error silencioso en notificacion: ${e.message}")
                }
            }
        }
    }
}
