package ogs.mag.nexozone

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ConversationActivity : AppCompatActivity() {

    private lateinit var messageAdapter: MessageAdapter
    private val messages = mutableListOf<Message>()
    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private var chatId: String = ""
    private var otherUid: String = ""
    private var myUsername: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_conversation)
        
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        if (auth.currentUser == null) {
            Toast.makeText(this, "Debes iniciar sesión para usar el chat", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val otherUsername = intent.getStringExtra("username") ?: "Chat"
        findViewById<TextView>(R.id.tvChatTitle).text = otherUsername

        val myEmail = auth.currentUser?.email ?: "anon"
        val myUid = auth.currentUser?.uid ?: ""
        
        db.collection("users").document(myUid).get().addOnSuccessListener { doc ->
            myUsername = doc.getString("username") ?: myEmail.substringBefore("@")
            myUsername = if (!myUsername.startsWith("@")) "@$myUsername" else myUsername
            android.util.Log.d("Chat", "Mi usuario cargado: $myUsername")
        }

        db.collection("users").whereEqualTo("username", otherUsername.removePrefix("@")).get()
            .addOnSuccessListener { query ->
                if (!query.isEmpty) {
                    val doc = query.documents[0]
                    otherUid = doc.id
                    val otherEmail = doc.getString("email") ?: ""
                    
                    // 1. Generar chatId SIMÉTRICO basado en correos
                    val emails = listOf(myEmail, otherEmail).sorted()
                    chatId = "${emails[0]}_${emails[1]}".replace("[^a-zA-Z0-9_]".toRegex(), "_")
                    android.util.Log.d("Chat", "ChatId generado: $chatId para $myEmail y $otherEmail")

                    // 2. Reiniciar unreadCount a 0 de forma segura en mi UID
                    val myUid = auth.currentUser?.uid ?: ""
                    val chatRef = db.collection("users").document(myUid).collection("recentChats").document(otherUsername.removePrefix("@"))
                    chatRef.set(hashMapOf("unreadCount" to 0), com.google.firebase.firestore.SetOptions.merge())

                    // 3. Empezar a escuchar mensajes ahora que el chatId es correcto
                    listenForMessages()
                    
                    // 4. Habilitar envío
                    findViewById<ImageButton>(R.id.btnSend).isEnabled = true
                }
            }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewMessages)
        messageAdapter = MessageAdapter(messages)
        recyclerView.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        recyclerView.adapter = messageAdapter

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            finish()
        }

        val etMessage = findViewById<EditText>(R.id.etMessage)
        val btnSend = findViewById<ImageButton>(R.id.btnSend)
        btnSend.isEnabled = false // Bloqueado hasta que cargue chatId
        
        btnSend.setOnClickListener {
            val text = etMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                sendMessage(text)
                etMessage.text.clear()
            }
        }
    }

    private fun listenForMessages() {
        if (auth.currentUser == null) return
        
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewMessages)
        db.collection("chats").document(chatId).collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    if (auth.currentUser != null) {
                        Toast.makeText(this, "Error cargando mensajes: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    messages.clear()
                    val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                    for (doc in snapshots) {
                        val content = doc.getString("content") ?: ""
                        val sender = doc.getString("sender") ?: ""
                        val timestamp = doc.getTimestamp("timestamp")
                        val time = if (timestamp != null) sdf.format(timestamp.toDate()) else "Ahora"
                        val isRead = doc.getBoolean("isRead") ?: false
                        
                        val isSentByMe = sender == auth.currentUser?.email
                        messages.add(Message(content, time, isSentByMe, isRead))

                        if (!isSentByMe && !isRead) {
                            db.collection("chats").document(chatId)
                                .collection("messages").document(doc.id)
                                .update("isRead", true)
                        }
                    }
                    messageAdapter.notifyDataSetChanged()
                    if (messages.isNotEmpty()) {
                        recyclerView.smoothScrollToPosition(messages.size - 1)
                    }
                }
            }
    }

    private fun sendMessage(content: String) {
        try {
            if (chatId.isBlank()) {
                Toast.makeText(this, "Error: Chat no inicializado", Toast.LENGTH_SHORT).show()
                return
            }

            val userEmail = auth.currentUser?.email ?: return
            val now = com.google.firebase.Timestamp.now()
            val messageData = hashMapOf(
                "content" to content,
                "sender" to userEmail,
                "isRead" to false,
                "timestamp" to now
            )

            db.collection("chats").document(chatId).collection("messages")
                .add(messageData)
                .addOnSuccessListener {
                    android.util.Log.d("Chat", "Mensaje enviado con éxito")
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Fallo al enviar mensaje (Firestore): ${e.message}", Toast.LENGTH_LONG).show()
                    e.printStackTrace()
                }
                
            // Actualizar recentChats emisor (en mi UID)
            val actualMyUid = auth.currentUser?.uid ?: ""
            val otherUsername = intent.getStringExtra("username") ?: "Chat"
            val myDocRef = db.collection("users").document(actualMyUid).collection("recentChats").document(otherUsername.removePrefix("@"))
            myDocRef.set(hashMapOf(
                "username" to otherUsername,
                "lastMessage" to content,
                "timestamp" to now,
                "unreadCount" to 0
            ))

            // Actualizar recentChats receptor (en su UID)
            if (otherUid.isNotEmpty() && myUsername.isNotEmpty()) {
                updateReceiverRecentChat(otherUid, myUsername, content, now)
            } else if (myUsername.isNotEmpty() && otherUid.isEmpty()) {
                android.util.Log.d("Chat", "Buscando otherUid para $otherUsername...")
                db.collection("users").whereEqualTo("username", otherUsername.removePrefix("@")).get()
                    .addOnSuccessListener { query ->
                        if (!query.isEmpty) {
                            otherUid = query.documents[0].id
                            updateReceiverRecentChat(otherUid, myUsername, content, now)
                        }
                    }
            } else {
                android.util.Log.e("Chat", "Faltan datos: otherUid=$otherUid, myUn=$myUsername")
            }
        } catch (e: Exception) {
            android.util.Log.e("ChatActivity", "Cierre evitado en envío: ${e.message}", e)
            Toast.makeText(this, "No se pudo enviar el mensaje", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateReceiverRecentChat(theirUid: String, myUn: String, content: String, now: com.google.firebase.Timestamp) {
        val theirDocRef = db.collection("users").document(theirUid).collection("recentChats").document(myUn.removePrefix("@"))
        theirDocRef.set(
            hashMapOf(
                "username" to myUn,
                "lastMessage" to content,
                "timestamp" to now,
                "unreadCount" to com.google.firebase.firestore.FieldValue.increment(1)
            ), com.google.firebase.firestore.SetOptions.merge()
        )
    }
}
